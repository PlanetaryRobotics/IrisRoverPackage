/*
 * blimp.h
 *
 *  Created on: Oct 17, 2021
 *      Author: iris
 */

#ifndef _BLIMP_H_
#define _BLIMP_H_

#include <stdint.h>
#include <msp430.h>

inline void blimp_bctrlEnOn();
inline void blimp_bctrlEnForceHigh();
inline void blimp_bctrlEnOff();
inline void blimp_latchBattOn();
inline void blimp_latchBattOff();
void blimp_latchBattUpdate();
inline void blimp_chargerEnOn();
inline void blimp_chargerEnForceHigh();
inline void blimp_chargerEnOff();
inline void blimp_regEnOn();
inline void blimp_regEnOff();
inline void blimp_battEnOn();
inline void blimp_battEnOff();
inline void blimp_vSysAllEnOn();
inline void blimp_vSysAllEnOff();

uint8_t blimp_cstat1();
uint8_t blimp_cstat2();
uint8_t blimp_isCharging();
uint8_t blimp_lstat();
uint8_t blimp_bstat();
uint8_t blimp_batteryState();


#endif /* INCLUDE_BLIMP_H_ */
